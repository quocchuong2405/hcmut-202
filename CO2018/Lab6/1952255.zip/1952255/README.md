# Lab 6

## How to run this mess

Step 1: `make all` or `make`

Step 2: `./mem <arg>`

Here `<arg>` can be 0, 1 or 2 as follows:

- 1: Use best fit algorithm
- 2: Use worst fit algorithm
- Otherwise: Use first fit algorithm

Step 3 (optional): `make clean` to remove this mess
